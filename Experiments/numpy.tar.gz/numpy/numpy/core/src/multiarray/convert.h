#ifndef _NPY_ARRAYOBJECT_CONVERT_H_
#define _NPY_ARRAYOBJECT_CONVERT_H_

NPY_NO_EXPORT int
PyArray_AssignZero(PyArrayObject *dst,
                   PyArrayObject *wheremask);

#endif
