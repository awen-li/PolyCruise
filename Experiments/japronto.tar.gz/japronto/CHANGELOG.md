0.1.1 - Feb 9 2017
------------------

- Native support for OSX
- Support for older hardware without SSE4.2
- Better crash info with faulthandler
