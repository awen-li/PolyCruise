#pragma once

int supports_x86_sse42(void);
