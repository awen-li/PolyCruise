header_errors = [
    'malformed_headers', 'incomplete_headers', 'invalid_headers',
    'excessive_data']
body_errors = ['malformed_body', 'incomplete_body']
