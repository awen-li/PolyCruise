```
go build .
GOMAXPROCS=1 ./bin
```
